
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>SVCEConnect</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Loading Bootstrap -->
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Loading Flat UI -->
    <link href="css/flat-ui.css" rel="stylesheet">
    <link href="css/demo.css" rel="stylesheet">

    <link rel="shortcut icon" href="images/favicon.ico">
  </head>
  <body>
    <br>  

  <!-- /sdfds-->

<center>

         <a href="index.php"> <img src="img/logo.png" width="220" height="130"></center></a>
       <h2><font color="#1980ea">SVCEConnect</h2></font><h3>Version:#1.0.0</h3>
    <BR>
       <H3> DEVELOPED BY: MD TABREZ ANSARI</H3><h5><a href="http://www.facebook.com/tabrezkhanprofile">More About Tabrez Ansari</a></h5><bR>
<H4> FEATURES DESIGN BY: YAWAR ABBAS NAJAR</H4><h5><a href="http://www.facebook.com/yawar4ali">More About Yawar Abbas</a></h5>
       <br><h5>Powered By:</h5>
       <h6>Our Education Partner: </h6>  <td class="mcnImageContent" style="padding-right: 0px;padding-left: 0px;padding-top: 0;padding-bottom: 0;mso-line-height-rule: exactly;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;" valign="top">
                                
                                    
                                        <img alt="" src="img/edumob.png" style="max-width: 257px;padding-bottom: 0;display: inline !important;vertical-align: bottom;border: 0;height: auto;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;" class="mcnImage" align="left" width="257">
                                    
                                
                            </td><br><br><br>
       <br>
	   <H6> Our Helper: SADDAM ALI</H6><h6><a href="http://www.facebook.com/samsaddam">More About Saddam Ali</a></h6><bR>
	    <H6> Our Helper: GAURAV NAYAK</H6><h6><a href="http://www.facebook.com/gauravnayak">More About Gaurav Nayak</a></h6><bR>







        

  <br>
  <div class="copyright">
     <center><b>Copyright @2016.SVCEConnect</b></center>
      </div>

  <!-- /sdfds-->
    <!-- /.container -->


    <!-- Load JS here for greater good =============================-->
    <script src="js/jquery-1.8.3.min.js"></script>
    <script src="js/jquery-ui-1.10.3.custom.min.js"></script>
    <script src="js/jquery.ui.touch-punch.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/bootstrap-switch.js"></script>
    <script src="js/flatui-checkbox.js"></script>
    <script src="js/flatui-radio.js"></script>
    <script src="js/jquery.tagsinput.js"></script>
    <script src="js/jquery.placeholder.js"></script>
  </body>
</html>