<!DOCTYPE html>
<html class=" js flexbox canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" idmmzcc-ext-docid="366364672"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>SVCEConnect</title>
<link href="js/js/style.css" type="text/css" rel="stylesheet">
<link href="js/js/style1.css" type="text/css" rel="stylesheet">
<link href="js/js/style2.css" type="text/css" rel="stylesheet">
 <link rel="stylesheet" type="text/css" href="js/js/coin-slider.css">
 <script type="text/javascript" src="js/js/jquery-1.js"></script>
<script type="text/javascript" src="js/js/script.js"></script>
<script type="text/javascript" src="js/js/coin-slider.js"></script>
<script src="js/js/klass.js" type="text/javascript"></script>
  <link rel="shortcut icon" href="images/favicon.ico">





<script src="js/js/jquery.htm" type="text/javascript"></script>

<script>window.jQuery || document.write('<script src="slider/js/libs/jquery-1.6.2.min.js"><\/script>')</script>

<script src="js/js/hoverIntent.js" type="text/javascript"></script>
<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0">

<script src="js/js/modernizr-2.js"></script>

<script src="js/js/shortcut.js" type="text/javascript"></script>


<link rel="stylesheet" href="js/js/responsiveslides.css">
  <link rel="stylesheet" href="js/js/themes.css">
  <script src="js/js/jquery-min.js"></script>
  <script src="js/js/responsiveslides.js"></script>
  <script>
    // You can also use "$(window).load(function() {"
    $(function () {

      // Slideshow 1
      $("#slider1").responsiveSlides({
        auto: true,
        pager: true,
        nav: true,
        speed: 800,
        maxwidth: 1400,
        namespace: "centered-btns"
      });

     

    });
  </script>
</head>




<body><center>
<div class="wrapper">
	<div class="header full-width">
		<div class="header-content centered clearfix">
			<div class="logo">


		  <img alt="" src="images/logo1.png" width="250" height="130" align="left"><br></div>
<div class="info clearfix">
				<div class="top-bar clearfix">
					<div class="content clearfix">
						<div class="accessibility">
							
						</div>
						<div class="social">
							
							
					  </div>
					</div>
				</div>
				<div class="search clearfix">
					
		  </div>

				<!--  
					<div class="tagline">
						<p class="anni-font">T&#332;U IWI, T&#332;U W&#256;NANGA</p>
						<p>Your people, your place</p>
					</div>
				-->
				
				<div class="tagline">
					
		  </div>


				
			</div>
		</div>
	</div>

	<div class="inner-header centered">
		<div class="BackendCssHide1">
			
			<ul class="nav clearfix">

		</div>
	</div>
	
 <div class="rslides_container">
      <ul style="max-width: 1400px;" class="rslides centered-btns centered-btns1" id="slider1">
        <li class="" style="display: block; float: none; position: absolute; opacity: 0; z-index: 1; transition: opacity 800ms ease-in-out 0s;" id="centered-btns1_s0"><img src="images/Slider%25201.PNG" alt="test " title="tets"> </li>
        <li class="" style="float: none; position: absolute; opacity: 0; z-index: 1; display: list-item; transition: opacity 800ms ease-in-out 0s;" id="centered-btns1_s1"><img src="images/Slider%25203.jpg" alt=""></li>
        <li class="" style="float: none; position: absolute; opacity: 0; z-index: 1; display: list-item; transition: opacity 800ms ease-in-out 0s;" id="centered-btns1_s2"><img src="images/Slider%25202.jpg" alt=""></li>
        
   
        <li class="centered-btns1_on" style="float: left; position: relative; opacity: 1; z-index: 2; display: list-item; transition: opacity 800ms ease-in-out 0s;" id="centered-btns1_s4"><img src="images/Slider%25208.jpg" alt=""></li>
    
        
      </ul></ul>
      <div class="full-width">

      </div><br><Br><br>
     
    </div>
	

      
  
<div class="full-width">
	<div class="main centered clearfix">
  
</div>
</div>



     
        

          



	<div class="footer-top full-width">
		<div class="centered clearfix">
	<div class="footer-menu-btn">
		</div>


	<a href="login.php"><font size="5" color="sky blue" style="Trebuchet MS">
			Student Login Portal</font></a><br>

   
		<div class="icons">
		   <a href="publicabt.php"><font size="3" color="sky blue" style="Trebuchet MS">About Us</font></a>

           
		</div>

	</div>
</div>

<div class="footer-bottom clearfix">
	<div class="centered clearfix">

		<div class="copyright">
			
			</div>
	</div>
</div>
<br>
</center>




	</div>



</body></html>