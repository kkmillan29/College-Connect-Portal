<?php include_once('connection.php'); ?>
<?PHP
session_start();
// variables

  $sid=$_SESSION['Reg_No'];
$from = $_POST["from"];
$sub = $_POST["sub"];
$message = $_POST["msg"];



 


$sql = mysql_query("INSERT INTO adminmsg VALUES('$from', '$sub','$message',NULL)");

// if message was sent then redirect user to the chat messages else display error
if (mysql_affected_rows() == 1)
{
  // PHP redirection
  echo "<h6>Thank Your For Your Message</h6>",'<strong>'.$from.'</strong>';
echo '<p><a href="home.php?Reg_No='.$sid.'">Go Back</a> to Home</p>';
}

mysql_close($link);
?>